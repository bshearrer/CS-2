//=============================
//Brandon Shearrer
//CS 2 - Assignment 1 
//Spring 2018
//=============================


public class Greeting
{
	public static void main(String[] args)
	{
		System.out.println("Hola mi nombre es Brandon!");
	}
}