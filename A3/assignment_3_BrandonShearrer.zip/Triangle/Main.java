//Assignment 3 Sierpinski's Triangle
//By: Brandon Shearrer
//CS 2 Spring 2018

public class Main
{
	public static void main(String[] args)
	{
		TFrame tFrame = new TFrame();
	}
}