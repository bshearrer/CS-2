How To Play:
Flags - left click flag icon to place/remove flags from gameboard
Reset - left click smiley face to reset gameboard