//Brandon Shearrer
//CS 2 - Assignment 3
//Spring 2018

import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;

public class Main
{
	public static void main(String[]args) 
	{
		new MessageFrame();
		new MessagePanel();
	}
}